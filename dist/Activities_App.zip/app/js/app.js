// Vue Instance
let app = new Vue({
    el: '#app',
    data: {
        deal: {
            id: null,
            name: null,
        },
        contacts: [],
        loading: false
    },
    computed: {

    },
    methods: {
        setDeal(dealId) {
            vm = this;
            vm.deal.id = dealId;
            // Get Deal Via API
            ZOHO.CRM.API.getRecord({Entity:"Deals", RecordID: dealId})
                .then(deal => {
                    console.log(deal.data[0]);
                    vm.deal.name = deal.data[0].Account_Name.name;

                });

            // Get Deal's Contacts via API
            ZOHO.CRM.API.getRelatedRecords({Entity: "Deals", RecordID: dealId, RelatedList: "Contact_Roles", page: 1, per_page: 200})
                .then(contacts => {

                    vm.contacts = contacts.data.map(contact => {
                        return {
                            name: contact.Full_Name,
                            id: contact.id,
                            inPerson: false,
                            call: false,
                            email: false,
                            social: false,
                            loading: false
                        };
                    });
                });
        },

        createActivities() {
            vm = this;
            vm.loading = true;
            for(let i = 0; i < vm.contacts.length; i++) {
                contact = vm.contacts[i];
                vm.contacts[i].loading = true;
                vm.executeFunction(contact)
                    .then(response => {
                        console.log(response);
                        vm.contacts[i].inPerson = false;
                        vm.contacts[i].call = false;
                        vm.contacts[i].email = false;
                        vm.contacts[i].social = false;
                        vm.contacts[i].loading = false;
                        if (i == vm.contacts.length - 1) {
                            vm.loading = false;
                        }
                    });
            }
        },

        executeFunction(contact) {
            let func_name = 'Create_Widget_Activites_Serverless';
            let req_data = {
                'deal_id': this.deal.id,
                'contact_id': contact.id,
                'in_person': contact.inPerson.toString(),
                'call': contact.call.toString(),
                'email': contact.email.toString(),
                'social': contact.social.toString()
            };
            return ZOHO.CRM.FUNCTIONS.execute(func_name, req_data);
        }
    },
    created() {
        // Get Deal Data from CRM
        vm = this;
        ZOHO.embeddedApp.on("PageLoad", entity => {
            vm.setDeal(entity.EntityId[0]);
        });
        
        // Initialize Widget Connection
        ZOHO.embeddedApp.init();
    },
    updated() {
        $('[data-toggle="tooltip"]').tooltip({delay: {show: 750, hide: 50}, trigger: "hover"});
    }
});