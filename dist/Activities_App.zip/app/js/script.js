
$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip({delay: {show: 750, hide: 50}, trigger: "hover"});
});